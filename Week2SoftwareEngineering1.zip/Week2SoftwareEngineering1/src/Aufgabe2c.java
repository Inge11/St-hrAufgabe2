public class Aufgabe2c {

}
