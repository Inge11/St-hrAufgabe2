

public class Aufgabe1c {
    int E,B,M;
    double expStringToDouble(String vor,String man,String exp){
        int S=1;
        if(vor.substring(0,1).equals("1")  && vor.length()==1){
            S=-1;
        }

            String m=man.substring(0,man.length()-1);
        int add=0;
        for(int i=0;i<m.length();i++){
           if( m.substring(i,i+1).equals("1")) {
              add+=pow (m.length() - i - 1);
           }




        }
        M=(add-1)/pow(exp.length());
        B=pow(exp.length()-1)-1;
        int adde=0;
        for(int i=0;i<exp.length();i++){
            if( exp.substring(i,i+1).equals("1")) {
                adde+=pow (m.length() - i - 1);
            }
        }
        E=adde+B;


        return (double) S*add*pow(adde);
    }

    private int pow(int i) {
        int res=1;
        for (int j=0;j<i;j++){
            res*=j;
        }
        return res;
    }
}
