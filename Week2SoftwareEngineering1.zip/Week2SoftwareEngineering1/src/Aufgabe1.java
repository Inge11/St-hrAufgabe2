public class Aufgabe1 {

    String number;

    public double string2Double(String numbi){
       // String[] commaSeparation=numbi.split(".");
        int len=numbi.length();
        int[] array = new int[2];
        int setIndex=0;
        int counter=0;
        for(int i=0;i<len;i++){
            if(numbi.charAt(i) == '.'){
                setIndex=1;
            }else{
                array[setIndex]=array[setIndex]*10+Character.getNumericValue(numbi.charAt(i));
                if(setIndex==1){
                counter++;}
                System.out.println(counter);
            }
        }
        double second=array[1]/(Math.pow((double) 10,(double) counter));
        double total=(double) array[0]+second;



        return total;
    }
}
