import java.util.ArrayList;
import java.util.List;

public class Aufgabe1b {


    public double stringToDouble(String str){
        StringBuilder sb=new StringBuilder(str);
        List<Integer> inBC=new ArrayList<Integer>();
        List<Integer> inAC=new ArrayList<Integer>();
        int afterComma=0;
        for(int i=0;i<sb.length();i++) {
          if( test(sb.charAt(i))){
              if(!(sb.charAt(i)==46) && afterComma==0) {
                  inBC.add(getNumericValueQ(sb.charAt(i)));
              }else{
                  afterComma+=1;
                  inAC.add(getNumericValueQ(sb.charAt(i)));
              }
          }
        }
        return makeDouble(inBC,inAC);

    }

    private Integer getNumericValueQ(char charAt) {
        switch(charAt){
            case 48: return 0;
            case 49: return 1;
            case 50: return 2;
            case 51: return 3;
            case 52: return 4;
            case 53: return 5;
            case 54: return 6;
            case 55: return 7;
            case 56: return 8;
            case 57: return 9;
            default: return -1;

        }
    }

    private boolean test(char charAt) {
        if(charAt<57  && charAt>48 || charAt==46){
            return true;
        }else{
            return false;
        }
    }
    //
    private double makeDouble(List<Integer> inBC, List<Integer> inAC) {
        int bcS=inBC.size();
        int acS=inAC.size();
        int before=getIntNumberB(bcS,inBC);
        double after=getIntNumberA(acS,inAC);
        return (double)before+after;

    }
    //Integer vor dem Komma xxx.
    private int getIntNumberB(int z, List<Integer> inAC) {
        int r=1;
        for(int i=0;i<z;i++){
            r+=makePos(z-1-i)*inAC.get(i);
        }
        return r;
    }
    // Integer nach dem Komma
    private double getIntNumberA(int z, List<Integer> inAC) {
        int r=1;
        for(int i=0;i<z;i++){
            r+=makePosA(z-1-i)*inAC.get(i);
        }
        return r;
    }
    //gibt die Nachkommastellen als eine Potenz von 10 aus, wird genutzt umd die Zahl später im dezimalsystem zudsammenzusetzen
    private int makePos(int k){
        int u=1;
        for(int i=0;i<k;i++){
            i=10*i;
        }
        return u;
    }

    //Dezimalstellen nach dem komma als eine Potens von 1/10(ein10tel) umd nachkommastellen zusammenzubauen
    private double makePosA(int k){
        int u=1;
        for(int i=0;i<k;i++){
            i=i/10;
        }
        return u;
    }
}
