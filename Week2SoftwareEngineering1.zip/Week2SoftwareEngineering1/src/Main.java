public class Main {
    public static void main(String[] args) {
        Aufgabe1 a1=new Aufgabe1();
        a1.number="123.45367";
        System.out.println(a1.string2Double(a1.number));
    }
}
